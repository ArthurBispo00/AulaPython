frase = str(input("Digite uma frase: "))
i = len(frase)
i = i - 1
while i > -1 :
 print(frase[i])
 i = i - 1
